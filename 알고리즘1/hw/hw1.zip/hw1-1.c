/* ID: 2016111683
* NAME: Lee SeungMin
* OS: linux, Ubuntu 16.04
* Compiler version: gcc 5.4.0 20160609
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student { int id; char name[128], major[128];};
int main(void){
    struct student *myself;
    myself = (struct student*)malloc(sizeof(struct student));
    myself->id=2016111683;
    strcpy(myself->name,"LeeSeungMin");
    strcpy(myself->major,"Software");
    printf("ID: %d\n", myself->id);
    printf("NAME: %s\n", myself->name);
    printf("MAJOR: %s\n", myself->major);
}

/* ID: 2016111683
* NAME: Lee SeungMin
* OS: linux, Ubuntu 16.04
* Compiler version: gcc 5.4.0 20160609
*/
#include<stdio.h>
#include<stdlib.h>

int main(int argc,char* argv[]){
    int temp,n1,n2,n3;
    n1=atoi(argv[1]);
    n2=atoi(argv[2]);
    n3=atoi(argv[3]);

    if(n1>n2){
    temp=n1;
    n1=n2;
    n2=temp;
    }
    if(n1>n3){
    temp=n1;
    n1=n3;
    n3=temp;
    }
    if(n2>n3){
    temp=n2;
    n2=n3;
    n3=temp;
    }

    printf("%d %d %d",n1,n2,n3);

}

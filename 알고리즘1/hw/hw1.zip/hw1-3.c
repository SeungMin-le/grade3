/* ID: 2016111683
* NAME: Lee SeungMin
* OS: linux, Ubuntu 16.04
* Compiler version: gcc 5.4.0 20160609
*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[]) {
    FILE *fp;
    int i, ndata, *A,num;
    int min,max,sum=0,vsum=0;
    float avg,v;
    fp = fopen(argv[1],"r");
    fscanf(fp, "%d", &num);
    A = (int*)malloc(sizeof(int)*num);
    ndata=num;
    for (i=0; i<ndata; i++){
        fscanf(fp, "%d", A+i);
    }
    min=A[0];
    max=A[0];
    for(int i=1;i<ndata;i++){
        if(min>A[i])
            min=A[i];
        if(max<A[i])
            max=A[i];
    }
    for(int i=0;i<ndata;i++){
        sum+=A[i];
        vsum+=A[i]*A[i];
    }
    avg=sum/(float)ndata;
    v=vsum/(float)ndata-avg*avg;

    printf("#data\t min\t max\t mean\t variance\n");
    printf("%d\t %d\t %d\t %.1f\t %.1f\n",ndata,min,max,avg,v);
    free(A);
    fclose(fp);
}
